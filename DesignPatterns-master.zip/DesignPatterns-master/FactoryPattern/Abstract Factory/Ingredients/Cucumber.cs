﻿namespace FactoryPattern
{
    internal class Cucumber : IVeggies
    {
        public string Name => "Cucumber";
    }
}