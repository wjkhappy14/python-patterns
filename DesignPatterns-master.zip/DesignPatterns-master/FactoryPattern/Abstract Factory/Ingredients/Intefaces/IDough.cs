﻿namespace FactoryPattern
{
    public interface IDough
    {
        string Name { get; }
    }
}