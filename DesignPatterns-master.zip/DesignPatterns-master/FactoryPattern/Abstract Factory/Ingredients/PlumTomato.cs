﻿namespace FactoryPattern
{
    internal class PlumTomato : ISauce
    {
        public string Name => "Plum Tomato";
    }
}