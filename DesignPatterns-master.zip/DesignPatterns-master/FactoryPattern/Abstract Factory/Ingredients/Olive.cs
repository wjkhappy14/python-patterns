﻿namespace FactoryPattern
{
    internal class Olive : IVeggies
    {
        public string Name => "Olives";
    }
}