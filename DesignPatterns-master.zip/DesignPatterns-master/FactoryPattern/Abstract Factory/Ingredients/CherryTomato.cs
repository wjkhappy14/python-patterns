﻿namespace FactoryPattern
{
    internal class CherryTomato : ISauce
    {
        public string Name => "Cherry Tomato";
    }
}