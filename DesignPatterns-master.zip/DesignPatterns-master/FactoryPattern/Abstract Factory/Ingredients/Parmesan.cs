﻿namespace FactoryPattern
{
    internal class Parmesan : ICheese
    {
        public string Name => "Parmesan";
    }
}