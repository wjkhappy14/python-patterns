﻿namespace Ducks
{
    internal interface IFlyBehaviour
    {
        void Fly();
    }
}
