﻿namespace StatePattern.Legacy
{
    public enum State
    {
        Sold, HasQuarters, NoQuarters, NoGumballs
    }
}