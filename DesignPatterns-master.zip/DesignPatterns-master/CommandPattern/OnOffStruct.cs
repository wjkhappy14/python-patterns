﻿namespace CommandPattern
{
    internal struct OnOffStruct
    {
        public ICommand On;
        public ICommand Off;
    }
}